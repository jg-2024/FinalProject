"""
Program FinalProject_GarrardJonathon
Author: Jonathon Garrard
Last date modified: 2024/3/9
Images taken from OpenMoji: https://openmoji.org/
OpenMoji is a royalty free library of emojis and can be used for creative
and commercial use. For more information, please visit their FAQ: https://openmoji.org/faq/
"""


# GUI Final Project
# When the user opens the app, they’re given a choice to log sleep or a nap via buttons.
# Regardless of what they choose, they’re asked to input a date, hours, and rate the quality of their sleep
# Once the user has answered those questions, they will hit save and the app will log the input as a night’s sleep or a nap.
# The app will track and output data:
    # Ongoing date tracking
    # Average hours of sleep for the week
    # Average nap time per day
    # Average quality of rest for both sleep and naps
    

# When you see a commented section with "A, B, C, etc." it is to indicate where
# code directly continues but has been broken into chunks for readability


# Import modules
import PIL
import image
import os
import tkinter as tk
from tkinter import *
from tkinter import ttk
from tkinter.messagebox import showinfo
from tkcalendar import Calendar, DateEntry
from datetime import date



# Define lists
# These lists are read and written from/to a file
# They track when the user slept, how many hours, and what rating they would give
nap_dates = []
nap_hours = []
nap_ratings = []
sleep_dates = []
sleep_hours = []
sleep_ratings = []


# Display a banner
print("")
print("FinalProject_GarrardJonathon: Sleepy Sheep Rest Tracker")


# Set local path to the current folder and print the folder path.
module_path = os.path.dirname(os.path.realpath(__file__))
input_path = os.path.join(module_path, "sleep.txt")
output_path = os.path.join(module_path, "sleep.txt")
print(f'File path is {input_path}')
print("")


# REST REPORT WINDOW A
# This corresponds with the "Generate Rest Report" button
# Opens a window that:
    ## Prints all dates recorded for nighttime rests and naps
    ## Prints total hours napped and slept
    # Average rating of sleep for the past seven recorded nighttime rests
    # Average rating of naps for the past seven recorded naps
    # Average hours of nighttime rests over the past seven recorded rests
    # Average hours of naps over the past seven recorded nap
class RestReport(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent)
# Add up total number of nap hours and sleep hours        
        total_naps = sum(nap_hours)
        total_rests = sum(sleep_hours)
# Add up the last seven recorded naps and nighttime rests
# Divide by 7 to get average
        weekly_naps = sum(nap_hours[-7:])
        average_naps = weekly_naps / 7
        weekly_rests = sum(sleep_hours[-7:])
        average_rests = weekly_rests / 7
        naptime_avg = sum(nap_ratings[-7:])
        naptime_score = naptime_avg / 7
        nighttime_avg = sum(sleep_ratings[-7:])
        nighttime_score = nighttime_avg / 7
        with open("sleep.txt", "r") as file:
# Display totals (two decimals)           
            label_one = ttk.Label(self, text=f"All dates you've taken a nap: {nap_dates}")
            label_one.grid(row=0, column=0, padx=10, pady=10)
            label_one.configure(anchor="center")            
            label_two = ttk.Label(self, text=f"Total hours you've napped: {total_naps:.2f}")
            label_two.grid(row=1, column=0, padx=10, pady=10)
            label_two.configure(anchor="center")           
            label_three = ttk.Label(self, text=f"All dates you've recorded nighttime rests: {sleep_dates}")
            label_three.grid(row=2, column=0, padx=10, pady=10)
            label_three.configure(anchor="center")
            label_four = ttk.Label(self, text=f"Total hours of recorded nighttime rest: {total_rests:.2f}")
            label_four.grid(row=3, column=0, padx=10, pady=10)
            label_four.configure(anchor="center")
# Display averages (two decimals)            
            label_five = ttk.Label(self, text=f"Average quality of your past seven recorded naps: {naptime_score:.2f}")
            label_five.grid(row=4, column=0, padx=10, pady=10)
            label_five.configure(anchor="center")                      
            label_six = ttk.Label(self, text=f"Average quality of your past seven recorded nighttime rests: {nighttime_score:.2f}")
            label_six.grid(row=5, column=0, padx=10, pady=10)
            label_six.configure(anchor="center")
            label_seven = ttk.Label(self, text=f"Average nap time over the past seven recorded naps: {average_naps:.2f}")
            label_seven.grid(row=6, column=0, padx=10, pady=10)
            label_seven.configure(anchor="center")                      
            label_eight = ttk.Label(self, text=f"Average hours nighttime rests over the past seven recorded nighttime rests: {average_rests:.2f}")
            label_eight.grid(row=7, column=0, padx=10, pady=10)
            label_eight.configure(anchor="center")


# SLEEP WINDOW A
# This is the sleep class
# This gives our sleep window (which looks similar to our nap window) unique properties
# Our sleep window opened in function open_sleep
class RecordSleep(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.geometry("420x650")
        self.title("Record Your Nighttime Rest")
# This prevents future date selection        
        today = date.today()


# SLEEP WINDOW B
# The below contains every label and entry field in the sleep window
# This is the label and entry for the first user input asking for the date the user slept
# This relies on module tkcalendar and module babel which are free downloads
        label_one = ttk.Label(self, text="                        Please select the date you went to bed.\nIf you went to bed past midnight, select the date prior to midnight:")
        label_one.grid(row = 0, column = 0, padx = 10, pady = 10)
        label_one.configure(anchor = "center")
        self.entry_one = DateEntry(self, maxdate = today, justify ="center")
        self.entry_one.grid(row = 1, column = 0, padx = 10, pady = 10)
        self.entry_one.focus()
# This is the label and entry for the second user input
        label_two = ttk.Label(self, text="How many hours did you sleep? Input in a XX.XX format. A half hour is 0.5:")
        label_two.grid(row = 2, column = 0, padx = 10, pady = 10)
        label_two.configure(anchor = "center")     
        self.entry_two = ttk.Entry(self, justify = "center")
        self.entry_two.grid(row = 3, column = 0, padx = 10, pady = 10)
        self.entry_two.focus()
# This is the label and entry for the third user input
# Radio buttons for the third user input which measures quality of nap
        label_three = ttk.Label(self, text="Please rate the quality of your nap:")
        label_three.grid(row = 4, column = 0, padx = 10, pady = 5)
        label_three.configure(anchor = "center")
        self.rest_quality = tk.IntVar()
        ttk.Radiobutton(self, text = "1", variable=self.rest_quality, value = 1).grid(row = 5, column = 0, padx = 150, pady = 5, sticky = "nsew")
        ttk.Radiobutton(self, text = "2", variable=self.rest_quality, value = 2).grid(row = 6, column = 0, padx = 150, pady = 5, sticky = "nsew")
        ttk.Radiobutton(self, text = "3", variable=self.rest_quality, value = 3).grid(row = 7, column = 0, padx = 150, pady = 5, sticky = "nsew")
        ttk.Radiobutton(self, text = "4", variable=self.rest_quality, value = 4).grid(row = 8, column = 0, padx = 150, pady = 5, sticky = "nsew")
        ttk.Radiobutton(self, text = "5", variable=self.rest_quality, value = 5).grid(row = 9, column = 0, padx = 150, pady = 5, sticky = "nsew")
# Resize and place images (emojis) next to radio buttons
        self.images = []
        for i in range(1, 6):
            img = tk.PhotoImage(file = f"Rating_{i}.png")
            img = img.subsample(10)  
            label = ttk.Label(self, image = img)
            label.image = img  
            label.grid(row = i+4, column = 0, padx = 150, pady = 5, sticky = "e")
            self.images.append(label)
        

# SLEEP WINDOW C
# This button writes the user input to a file        
# Makes sure the user has entered hours slept and a score
# If not, throws up an error window
# If so, it tracks all data in text file
# And then the button closes the sleep window
# The user then is returned to the first window where they can log another nighttime rest, log nap, or generate a report in "# START APP A"
        ttk.Button(self, text = "Save & Close", command = self.sleep_validate).grid(row = 10, column = 0, pady = 25)
    def sleep_validate(self):
                      user_date = self.entry_one.get()
                      user_hours = self.entry_two.get()
                      user_score = self.rest_quality.get()
                      try:
                          user_hours = float(user_hours)                      
                      except ValueError:
                          self.get_error()
                          return
                      if int(user_score) <= 0:
                          self.get_error()
                          return
                      sleep_dates.append(user_date)
                      sleep_hours.append(user_hours)
                      sleep_ratings.append(user_score)
                      with open("sleep.txt", "w") as file:                          
                          file.write(str(f"NAP_DATES START:{nap_dates}:NAP_DATES END\nNAP_HOURS START:{nap_hours}:NAP_HOURS END\nNAP_SCORES START:{nap_ratings}:NAP_SCORES END\nSLEEP_DATES START:{sleep_dates}:SLEEP_DATES END\nSLEEP_HOURS START:{sleep_hours}:SLEEP_HOURS END\nSLEEP_SCORES START:{sleep_ratings}:SLEEP_SCORES END"))
                          self.destroy()
# Calls "# ERROR WINDOW" if input isn't valid or is missing
    def get_error(self):
        error_message = Error()


# NAP WINDOW A
# This is the nap class
# This gives our nap window (which looks similar to our sleep window) unique properties
# Our nap window opened in function open_nap
class RecordNap(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.geometry("420x630")
        self.title("Record Your Nap")
# This prevents future date selection        
        today = date.today()
        

# NAP WINDOW B
# The below contains every label and entry field in the nap window
# This is the label and entry for the first user input asking for the date the user slept
# This relies on module tkcalendar and module babel which are free downloads
        label_one = ttk.Label(self, text="Please select the date you're recording this nap for:")
        label_one.grid(row = 0, column = 0, padx = 10, pady = 10)
        label_one.configure(anchor = "center")
        self.entry_one = DateEntry(self, maxdate = today, justify ="center")
        self.entry_one.grid(row = 1, column = 0, padx = 10, pady = 10)
        self.entry_one.focus()
# This is the label and entry for the second user input
        label_two = ttk.Label(self, text="How many hours did you sleep? Input in a XX.XX format. A half hour is 0.5:")
        label_two.grid(row = 2, column = 0, padx = 10, pady = 10)
        label_two.configure(anchor = "center")     
        self.entry_two = ttk.Entry(self, justify = "center")
        self.entry_two.grid(row = 3, column = 0, padx = 10, pady = 10)
        self.entry_two.focus()
# This is the label and entry for the third user input
# Radio buttons for the third user input which measures quality of nap
        label_three = ttk.Label(self, text="Please rate the quality of your nap:")
        label_three.grid(row = 4, column = 0, padx = 10, pady = 5)
        label_three.configure(anchor = "center")
        self.rest_quality = tk.IntVar()
        ttk.Radiobutton(self, text = "1", variable=self.rest_quality, value = 1).grid(row = 5, column = 0, padx = 150, pady = 5, sticky = "nsew")
        ttk.Radiobutton(self, text = "2", variable=self.rest_quality, value = 2).grid(row = 6, column = 0, padx = 150, pady = 5, sticky = "nsew")
        ttk.Radiobutton(self, text = "3", variable=self.rest_quality, value = 3).grid(row = 7, column = 0, padx = 150, pady = 5, sticky = "nsew")
        ttk.Radiobutton(self, text = "4", variable=self.rest_quality, value = 4).grid(row = 8, column = 0, padx = 150, pady = 5, sticky = "nsew")
        ttk.Radiobutton(self, text = "5", variable=self.rest_quality, value = 5).grid(row = 9, column = 0, padx = 150, pady = 5, sticky = "nsew")
# Resize and place images (emojis) next to radio buttons
        self.images = []
        for i in range(1, 6):
            img = tk.PhotoImage(file = f"Rating_{i}.png")
            img = img.subsample(10)  
            label = ttk.Label(self, image = img)
            label.image = img  
            label.grid(row = i+4, column = 0, padx = 150, pady = 5, sticky = "e")
            self.images.append(label)


# NAP WINDOW C
# This button writes the user input to a file        
# Makes sure the user has entered hours slept and a score
# If not, throws up an error window
# If so, it tracks all data in text file
# And then the button closes the nap window
# The user then is returned to the first window where they can log another nap, log sleep, or generate a report in "# START APP A"
        ttk.Button(self, text = "Save & Close", command = self.nap_validate).grid(row = 10, column = 0, pady = 25)
    def nap_validate(self):
                      user_date = self.entry_one.get()
                      user_hours = self.entry_two.get()
                      user_score = self.rest_quality.get()
                      try:
                          user_hours = float(user_hours)                      
                      except ValueError:
                          self.get_error()
                          return
                      if int(user_score) <= 0:
                          self.get_error()
                          return
                      nap_dates.append(user_date)
                      nap_hours.append(user_hours)
                      nap_ratings.append(user_score)
                      with open("sleep.txt", "w") as file:                          
                          file.write(str(f"NAP_DATES START:{nap_dates}:NAP_DATES END\nNAP_HOURS START:{nap_hours}:NAP_HOURS END\nNAP_SCORES START:{nap_ratings}:NAP_SCORES END\nSLEEP_DATES START:{sleep_dates}:SLEEP_DATES END\nSLEEP_HOURS START:{sleep_hours}:SLEEP_HOURS END\nSLEEP_SCORES START:{sleep_ratings}:SLEEP_SCORES END"))
                          self.destroy()
# Calls "# ERROR WINDOW" if input isn't valid or is missing
    def get_error(self):
        error_message = Error()


# ERROR WINDOW
# This error window pops up when user doesn't input data in the correct format and is called by "# NAP WINDOW D" and "#SLEEP WINDOW"
class Error(tk.Tk):
    def __init__(self):
        super().__init__()
        self.geometry("350x100")
        self.title("Error")
        self.configure(bg = "#137AAD")
        label_error = ttk.Label(self, text = "Please close this window and input data in the correct format.")
        label_error.grid(row=0, column = 1, padx = 10, pady = 30)
        label_error.configure(anchor="center")


# START APP B
# Open a window with set dimensions, title, and background color
class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.geometry("350x400")
        self.title("Sleepy Sheep Rest Tracker")
        self.configure(bg = "#137AAD")


# START APP C
# Place "Log Nap," "Log Sleep," and "Generate Rest Report" buttons in the first window
        ttk.Button(self,
                text = "Log Nap",
                command = self.open_nap).place(relx = 0.5, rely = 0.20, anchor = tk.CENTER)
        ttk.Button(self,
                text = "Log Sleep",
                command = self.open_sleep).place(relx = 0.5, rely = 0.50, anchor = tk.CENTER)   
        ttk.Button(self,
                text = "Generate Rest Report",
                command = self.rest_report).place(relx = 0.5, rely = 0.80, anchor = tk.CENTER)
# If the user clicked "Log Nap," it opens "# NAP WINDOW A"     
    def open_nap(self):
        nap_window = RecordNap(self)
        nap_window.grab_set()
# If the user clicked "Log Sleep," it opens "# SLEEP WINDOW A"
    def open_sleep(self):
        sleep_window = RecordSleep(self)
        sleep_window.grab_set()
# If the user clicked "Generate Rest Report," it opens "# REST REPORT WINDOW A"
    def rest_report(self):
        report_window = RestReport(self)
        report_window.grab_set()


# START APP A
# This is the beginning of the program
# If program is being run directly, run program
# Open our sleep file and see if there are any contents
# If so, assign those to our lists
# Make sure they're in the proper format so when we generate our rest report we don't run into errors
# Close file
# This continues in "# START APP B" above this chunk of code
if __name__ == "__main__":
    with open("sleep.txt", "r") as file:
        for line in file:
            if "NAP_DATES" in line:
                dates = line.split("NAP_DATES START:")[1].split(":NAP_DATES END")[0]
                nap_dates = dates.strip("[]").replace("'", "").split(", ")
            elif "NAP_HOURS" in line:
                hours = line.split("NAP_HOURS START:")[1].split(":NAP_HOURS END")[0]
                nap_hours = list(map(float, hours.strip("[]").split(", ")))
            elif "NAP_SCORES" in line:
                scores = line.split("NAP_SCORES START:")[1].split(":NAP_SCORES END")[0]
                nap_ratings = list(map(int, scores.strip("[]").split(", ")))
            elif "SLEEP_DATES" in line:
                dates = line.split("SLEEP_DATES START:")[1].split(":SLEEP_DATES END")[0]
                sleep_dates = dates.strip("[]").replace("'", "").split(", ")
            elif "SLEEP_HOURS" in line:
                hours = line.split("SLEEP_HOURS START:")[1].split(":SLEEP_HOURS END")[0]
                sleep_hours = list(map(float, hours.strip("[]").split(", ")))
            elif "SLEEP_SCORES" in line:
                scores = line.split("SLEEP_SCORES START:")[1].split(":SLEEP_SCORES END")[0]
                sleep_ratings = list(map(int, scores.strip("[]").split(", ")))
    file.close()
    app = App()
    app.mainloop()
